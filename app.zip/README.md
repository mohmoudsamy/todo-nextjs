### PROJECT_PASSWORD ==> Di3qpnYlGJmwDA7w

### ANON_KEY ==> eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZ3Z2RoeXhpbnVrY3d3Z2JzcGhxIiwicm9sZSI6ImFub24iLCJpYXQiOjE2ODM1MzM4ODksImV4cCI6MTk5OTEwOTg4OX0.tvxdgt1V1QJuWRL_yJRo4ukhlDzjy0g_046T85txthw

### URL ==> https://vwgdhyxinukcwwgbsphq.supabase.co

### JWT secret ==> 6jNY5AEE3F9ExGAysjku33q6XFr28rxzWRSavLYnJ2THcl1u6/9a2VyV401ZTNybb06YbYqPovIgwVr+9omVrQ==
