import React from "react";

const Loading = () => {
  return <h1 className="text-3xl text-primary text-center">Loading...</h1>;
};

export default Loading;
