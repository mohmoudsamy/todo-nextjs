const Meta = () => {
  return (
    <>
      <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
      <meta name="Author" content="Fresher" />
      <title>TODO - Next JS</title>
    </>
  );
};

export default Meta;
